const doctors=[
{id:1,name:"Dr. Ananya Sharma",specialty:"Cardiologist",experience:"12 years",fee:"₹800",emoji:"👩‍⚕️"},
{id:2,name:"Dr. Rohan Mehta",specialty:"Dermatologist",experience:"8 years",fee:"₹600",emoji:"👨‍⚕️"},
{id:3,name:"Dr. Neha Kulkarni",specialty:"Pediatrician",experience:"10 years",fee:"₹700",emoji:"👩‍⚕️"},
{id:4,name:"Dr. Arjun Deshmukh",specialty:"General Physician",experience:"15 years",fee:"₹500",emoji:"👨‍⚕️"},
{id:5,name:"Dr. Priya Joshi",specialty:"Dentist",experience:"7 years",fee:"₹600",emoji:"👩‍⚕️"},
{id:6,name:"Dr. Sameer Patil",specialty:"Cardiologist",experience:"9 years",fee:"₹750",emoji:"👨‍⚕️"}
];
function renderDoctors(){
 const grid=document.getElementById("doctorGrid"), search=document.getElementById("search"), specialty=document.getElementById("specialty");
 function draw(){let q=(search.value||"").toLowerCase(),s=specialty.value;let list=doctors.filter(d=>(d.name.toLowerCase().includes(q)||d.specialty.toLowerCase().includes(q))&&(!s||d.specialty===s));
 grid.innerHTML=list.length?list.map(d=>`<div class="card doctor-card"><div class="doctor-avatar">${d.emoji}</div><h3>${d.name}</h3><b>${d.specialty}</b><div class="meta">Experience: ${d.experience}<br>Consultation: ${d.fee}</div><a class="btn" href="booking.html?doctor=${d.id}">Book Appointment</a></div>`).join(""):'<div class="card empty">No doctors found.</div>'}
 search.oninput=draw;specialty.onchange=draw;
 const url=new URLSearchParams(location.search);if(url.get("specialty"))specialty.value=url.get("specialty");draw();
}
function populateDoctorSelect(){
 const select=document.getElementById("doctorSelect"); if(!select)return;
 const id=new URLSearchParams(location.search).get("doctor");
 select.innerHTML='<option value="">Select doctor</option>'+doctors.map(d=>`<option value="${d.name}" ${String(d.id)===id?"selected":""}>${d.name} — ${d.specialty}</option>`).join("");
 document.getElementById("bookingForm").addEventListener("submit",e=>{e.preventDefault();let f=new FormData(e.target);let ap={id:Date.now(),patient:f.get("patient"),email:f.get("email"),doctor:f.get("doctor"),date:f.get("date"),time:f.get("time"),reason:f.get("reason"),status:"Confirmed"};let arr=JSON.parse(localStorage.getItem("appointments")||"[]");arr.push(ap);localStorage.setItem("appointments",JSON.stringify(arr));alert("Appointment booked successfully!");location.href="dashboard.html"});
}
function renderAppointments(){
 let arr=JSON.parse(localStorage.getItem("appointments")||"[]");document.getElementById("totalCount").textContent=arr.length;document.getElementById("upcomingCount").textContent=arr.filter(x=>x.status!=="Cancelled").length;
 const box=document.getElementById("appointmentList");if(!arr.length){box.innerHTML='<div class="empty">No appointments yet. <a href="booking.html">Book your first appointment</a>.</div>';return}
 box.innerHTML=`<table><thead><tr><th>Doctor</th><th>Date</th><th>Time</th><th>Status</th><th>Action</th></tr></thead><tbody>${arr.map(a=>`<tr><td>${a.doctor}</td><td>${a.date}</td><td>${a.time}</td><td><span class="status ${a.status==="Cancelled"?"cancel":"confirmed"}">${a.status}</span></td><td>${a.status!=="Cancelled"?`<button class="btn small" onclick="cancelAppointment(${a.id})">Cancel</button>`:"—"}</td></tr>`).join("")}</tbody></table>`;
}
function cancelAppointment(id){let arr=JSON.parse(localStorage.getItem("appointments")||"[]");let x=arr.find(a=>a.id===id);if(x&&confirm("Cancel this appointment?")){x.status="Cancelled";localStorage.setItem("appointments",JSON.stringify(arr));renderAppointments()}}
function loginDemo(e){e.preventDefault();alert("Demo login successful! Redirecting to Patient Dashboard.");location.href="dashboard.html"}
