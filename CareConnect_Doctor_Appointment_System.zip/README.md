# CareConnect — Doctor Appointment System

## College Project Demo
A responsive frontend prototype for a Doctor Appointment System.

### Features
- Home page
- Doctor search and specialty filter
- Appointment booking
- Appointment confirmation
- LocalStorage-based appointment records
- Patient dashboard
- Appointment cancellation
- Doctor dashboard
- Admin dashboard
- Demo login

### How to run
1. Extract the ZIP.
2. Open `index.html` in Chrome/Edge.
3. Use **Find a Doctor** or **Book Appointment**.
4. Book an appointment and open **Patient Dashboard**.
5. Appointments are stored in the browser's LocalStorage.

### Final college version
The frontend can later be connected to:
HTML/CSS/JavaScript → Java Backend → JDBC → MySQL

This version is intentionally a working browser demo and does not contain real patient/medical data.
